function Death(){
    return true;
}