var a = 0;
function max(){
    a += 888;
    return a;
}